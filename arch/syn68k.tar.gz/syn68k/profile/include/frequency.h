#ifndef _frequency_h_
#define _frequency_h_

extern void generate_frequency_report (void);

#endif  /* Not _frequency_h_ */
