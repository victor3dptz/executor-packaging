#ifndef _amode_h_
#define _amode_h_

extern const char *amode_to_string (int amode);

#endif  /* Not _amode_h_ */
