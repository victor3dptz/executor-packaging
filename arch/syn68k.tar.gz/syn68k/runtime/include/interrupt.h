#ifndef _interrupt_h_
#define _interrupt_h_

#include "syn68k_private.h"

/* Everything that would normally be here is in syn68k_public.h */

#endif  /* Not _interrupt_h_ */
