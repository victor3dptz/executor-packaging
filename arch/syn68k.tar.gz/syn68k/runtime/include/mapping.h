#ifndef _mapping_h_
#define _mapping_h_

#include "syn68k_private.h"

extern const uint16 opcode_map_index[];
extern const OpcodeMappingInfo opcode_map_info[];

#endif  /* Not _mapping_h_ */
