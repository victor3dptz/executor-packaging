#ifndef _callemulator_h_
#define _callemulator_h_

extern int call_emulator (int (*func)(), ...);

#endif  /* Not _callemulator_h_ */
