#ifndef _testtrap_h_
#define _testtrap_h_

extern void test_traps (void);

#endif  /* Not _testtrap_h_ */
