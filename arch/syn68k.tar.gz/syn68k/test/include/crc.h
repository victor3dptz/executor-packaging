#ifndef _crc_h_
#define _crc_h_

extern unsigned short compute_crc (unsigned char *data, long length,
				   unsigned short seed);

#endif  /* Not _crc_h_ */
