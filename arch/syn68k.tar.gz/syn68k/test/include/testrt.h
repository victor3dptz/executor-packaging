#ifndef _testrt_h_
#define _testrt_h_

extern void test_rangetree (void);

#endif  /* Not _testrt_h_ */
