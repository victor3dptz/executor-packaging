#ifndef _testqsort_h_
#define _testqsort_h_

extern void test_qsort (void);

#endif  /* _testqsort_h_ */
