#ifndef _run68k_h_
#define _run68k_h_

#include "syn68k_public.h"

extern void run_code_on_68000 (uint16 *code, uint32 *return_address);

#endif  /* Not _run68k_h_ */
