#ifndef __UNIQUESTRING_H__
#define __UNIQUESTRING_H__

extern void init_unique_string (void);
extern const char *unique_string (const char *s);

#endif  /* Not __UNIQUESTRING_H__ */
